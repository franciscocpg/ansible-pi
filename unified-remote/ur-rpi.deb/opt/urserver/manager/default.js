var tid;
var ractive;
var model;
var tiptid;
var first;
var log;


$.postJSON = function (url, data) {
	return $.ajax({
		type: 'POST',
		url: url,
		data: JSON.stringify(data),
		contentType: "application/json",
		dataType: 'json'
	});
}


function update() {
	ractive.set(model);
}


function navigate(path) {
	path = path.substr(path.indexOf('#'));
	var split = path.split("/");
	ractive.set("view.page.*", false);
	ractive.set("view.tab.*", false);
	if (split.length >= 2)
		ractive.set("view.page." + split[1], true);
	if (split.length >= 3)
		ractive.set("view.tab." + split[2], true);
	else
		ractive.set("view.tab.default", true);
}

function getStatusView(m) {
	if (m.interfaces.ad.status == "Disabled") {
		m.interfaces.ad.view = { icon: "ban", style: "", text: "Interface is disabled" };
	} else if (m.interfaces.ad.status == "Started") {
		m.interfaces.ad.view = { icon: "check", style: "ok", text: "Interface is listening" };
	} else {
		m.interfaces.ad.view = { icon: "times", style: "error", text: m.interfaces.ad.error };
	}

	if (m.interfaces.wifi.status == "Disabled") {
		m.interfaces.wifi.view = { icon: "ban", style: "", text: "Interface is disabled" };
	} else if (m.interfaces.wifi.status == "Started") {
		m.interfaces.wifi.view = { icon: "check", style: "ok", text: "Interface is listening" };
	} else {
		m.interfaces.wifi.view = { icon: "times", style: "error", text: m.interfaces.wifi.error };
	}

	if (m.interfaces.bt.status == "Disabled") {
		m.interfaces.bt.view = { icon: "ban", style: "", text: "Interface is disabled" };
	} else if (m.interfaces.bt.status == "Started") {
		m.interfaces.bt.view = { icon: "check", style: "ok", text: "Interface is listening" };
		} else if (m.interfaces.bt.status == "NotSupported") {
				m.interfaces.bt.view = { icon: "ban", style: "", text: "Not supported on current OS" };
		} else if (m.interfaces.bt.status == "NotAvailable") {
				m.interfaces.bt.view = { icon: "ban", style: "", text: "Radio is not available" };
	} else {
		m.interfaces.bt.view = { icon: "times", style: "error", text: m.interfaces.bt.error };
	}

	if (m.network.lan.available) {
		m.network.lan.view = { icon: "check", style: "ok", text: "Detected" };
	} else {
		m.network.lan.view = { icon: "times", style: "error", text: "Not Detected" };
	}

	if (m.network.wan.available) {
		m.network.wan.view = { icon: "check", style: "ok", text: "Detected" };
	} else {
		m.network.wan.view = { icon: "times", style: "error", text: "Not Detected" };
	}

	if (m.firewall.available) {
		if (m.firewall.allowed) {
			m.firewall.view = { icon: "check", style: "ok", text: "Access is allowed" };
		} else {
			m.firewall.view = { icon: "times", style: "error", text: "Access not allowed. Check firewall settings..." };
		}
	}

	m.input.view = { icon: "check", style: "ok", text: m.input.mode };

	return m;
}


function onConnected() {
	fetchRemotes();
	fetchConfig();
	fetchRemotes();
}


function fetchStatus() {
	model.view.restarting = false;

		$.getJSON("/system/status", function (data) {
		if (model.view.restarting) {
			return;
		}
		if (!model.view.connected || first) {
			if (!first)
				tip("Connected");
			model.view.connected = true;
			model.view.restarting = false;
			first = false;
			onConnected();
		}
		model.status = getStatusView(data);
		update();
	})
	.fail(function (jqXHR, textStatus, errorThrown) {
		if (model.view.restarting) {
			return;
		}
		if (model.view.connected) {
			model.view.connected = false;
			tip("Disconnected");
		}
		model.status.interfaces.wifi.view = { icon: "times", style: "", text: "Checking..." };
		model.status.interfaces.bt.view = { icon: "times", style: "", text: "Checking..." };
		model.status.interfaces.ad.view = { icon: "times", style: "", text: "Checking..." };
		model.status.network.lan.view = { icon: "times", style: "", text: "Checking..." };
		model.status.network.wan.view = { icon: "times", style: "", text: "Checking..." };
		model.status.firewall.view = { icon: "times", style: "", text: "Checking..." };
		model.status.input.view = { icon: "times", style: "", text: "Checking..." };
		update();
	})
	.always(function () {
		if (model.view.restarting) {
			return;
		}
		tid = setTimeout(fetchStatus, 1000);
	});

	var l = model.view.log;
	var url_postfix = "/" + [l.lines, l.level, l.filter].join("/");

	var lineToItem = function(itm) {
		var split = itm.split(" ");
		return {
			line: itm,
			date: split[0],
			time: split[1],
			tag: model.log_levels[_.trim(split[2], "()")].name,
			msg: _.slice(split, 3).join(" ")
		};
	};

	$.getJSON("/system/log" + url_postfix, function (json) {
		var new_lines = json.data;
		var $log = $("#log-data");

		// Log element not visible
		if ($log.size() === 0) return;

		// Mismatch in length
		if ($log.children().length !== l.data.length) l.data = [];

		// Has search params changed ?
		if (l.last_url_postfix === url_postfix) {

			// same search term, do update!
			_.forEach(l.data, function (old) {
				_.remove(new_lines, function (i) {
					return i === old.line;
				});
			});

			var new_items = _.map(new_lines, lineToItem);
			_.forEach(new_items, function(itm) {
				l.data.unshift(itm);
			});

			$log.prepend(templateRender("#tlogline", {log: new_items}));

			var lines_now = l.data.length;
			var lines_max = l.lines;
			var exceed = Math.max(lines_now - lines_max, 0);
			_.times(exceed, function() {
				$log.find(".log-line:last-child").remove();
				l.data.pop();
			});

		} else {
			// new search term, flush
			l.data = _.map(new_lines, lineToItem);
			$log.html(templateRender("#tlogline", {log: l.data}));
		}
		l.last_url_postfix = url_postfix;
	})
}

var templateRender = function(template, data){
	var ractive = new Ractive({
		template: template,
		data: data
	});
	return ractive.toHTML();
};

function sortRemotes(a,b) {
	if (a.id == "Relmtech.Basic Input") return -1;
	if (b.id == "Relmtech.Basic Input") return 1;
	a = a.name.toLowerCase();
	b = b.name.toLowerCase();
	if (a < b) return -1;
	if (a > b) return 1;
	return 0;
}


function fetchRemotes() {
	$.getJSON("/system/remotes", function (data) {
		data.sort(sortRemotes);
		model.remotes = data;
		update();
	});
}


function fetchConfig() {
	$.getJSON("/system/config", function (data) {
		model.config = data;
		update();
	});
}


function tip(s) {
	ractive.set("view.tip", s);
	var $tips = $(".tips");
	$tips.hide();
	clearTimeout(tiptid);
	$tips.slideDown(100, function () {
		tiptid = setTimeout(function () {
			$(".tips").slideUp(100);
		}, 2000);
	});
}

function saveConfig() {
	model.view.unsaved = {};
	$.postJSON("/system/config", model.config);
	restart();
}

function restart() {
	clearTimeout(tid);
	model.view.restarting = true;
	model.view.connected = false;
	update();
	$.get("/system/restart");
	tid = setTimeout(fetchStatus, 3000);
}

function isRemoteDisabled (id) {
	return !isRemoteEnabled(id);
}
function isRemoteEnabled (id) {
	return $.inArray(id, model.config.loader.disabled) == -1;
}
function isRemoteUnsaved (id) {
	return model.view.unsaved[id] == true;
}

$(document).ready(function () {
	first = true;
	log = "";
		model = {
		year: new Date().getFullYear(),
		view: {
			restarting: false,
			connected: true,
			showhidden: false,
			tip: "",
			page: { status: true },
			tab: { dashboard: true },
			unsaved: {},
			log : {
				last_url_postfix: undefined,
				data: [],
				lines: 50,
				filter: "",
				level: 6
			}
		},
		log_levels: {
			F: {name: "fatal", 		int: 1},
			C: {name: "critical", 	int: 2},
			E: {name: "error", 		int: 3},
			W: {name: "warning", 	int: 4},
			N: {name: "notice", 	int: 5},
			I: {name: "info", 		int: 6},
			D: {name: "debug", 		int: 7},
			T: {name: "trace", 		int: 8}
		},
		view_log_levels: [
			{name: "fatal", 	int: 1},
			{name: "error", 	int: 3},
			{name: "warning", 	int: 4},
			{name: "info", 		int: 6},
			{name: "trace", 	int: 8}
		],
		isRemoteDisabled: isRemoteDisabled,
		isRemoteEnabled: isRemoteEnabled,
		isRemoteUnsaved: isRemoteUnsaved
	};

	ractive = new Ractive({
		el: "container",
		template: "#tmain",
		data: model
	});

	ractive.on({
		navigate: function (e) {
			navigate(e.node.getAttribute("href"));
		},
		"save-config": function (e) {
			saveConfig();
		},
		"cancel-config": function (e) {
			tip("Reverted changes");
			fetchConfig();
		},
		"remove-path": function (e) {
			var i = e.node.getAttribute("data-index");
			model.config.loader.paths.splice(i, 1);
			update();
		},
		"add-path": function (e) {
			model.config.loader.paths.push("");
			update();
		},
		"restart": function (e) {
			restart();
		},
		"reload": function (e) {
			$.get("/system/reload");
			tip("Reloading remotes");
		},
		"enable-all-remotes": function (e) {
			model.config.loader.disabled = [];
			update();
			saveConfig();
		},
		"disable-all-remotes": function (e) {
			for (var i = 0; i < model.remotes.length; i++) {
				var remote = model.remotes[i];
				if ($.inArray(remote.id, model.config.loader.disabled) == -1)
					if (!remote.hidden || model.view.showhidden)
						model.config.loader.disabled.push(remote.id);
			}
			update();
			saveConfig();
		},
		"update-check": function (e) {
			tip("Checking for updates");
			$.getJSON("/system/update-force", function (data) {
				if (data.Available) {
					tip("Update available");
				} else {
					tip("No updates available");
				}
				fetchConfig();
			});
		},
		"update-ignore": function (e) {
			$.get("/system/update-ignore");
			fetchConfig();
		},
		"update-later": function (e) {
			$.get("/system/update-later");
						fetchConfig();
		},
		"enable-remote": function (e) {
			var id = e.node.getAttribute("data-id");
			var i = model.config.loader.disabled.indexOf(id);
			if (i > -1) {
				model.config.loader.disabled.splice(i, 1);
								model.view.unsaved[id] = !(model.view.unsaved[id] == true);
				update();
			} else {
				tip("Already enabled");
			}
		},
		"disable-remote": function (e) {
			var id = e.node.getAttribute("data-id");
			var i = model.config.loader.disabled.indexOf(id);
			if (i == -1) {
							model.config.loader.disabled.push(id);
							model.view.unsaved[id] = !(model.view.unsaved[id] == true);
							update();
			} else {
				tip("Already disabled");
			}
		},
		"save-remotes": function (e) {
			saveConfig();
		},
		"configure-remote": function (e) {
			var i = e.node.getAttribute("data-index");
			model.view.remote = model.remotes[i];
			update();
		},
		"configure-users": function (e) {
			navigate("/web/#/settings/users");
		},
		"add-user": function (e) {
			model.config.security.users.push({ username: "", password: "" });
			update();
		},
		"remove-user": function (e) {
			var i = e.node.getAttribute("data-index");
			model.config.security.users.splice(i, 1);
			update();
		},
		"save-remote-settings": function (e) {
			tip("Saving settings");
			$.postJSON("/system/remote-settings/" + model.view.remote.id, model.view.remote.settings);
			delete model.view.remote;
			update();
		},
		"cancel-remote-settings": function (e) {
			delete model.view.remote;
			update();
		},
		"add-remote-setting": function (e) {
			model.view.remote.settings.push({ key: "", value: "" });
			update();
		},
		"remove-remote-setting": function (e) {
			var i = e.node.getAttribute("data-index");
			model.view.remote.settings.splice(i, 1);
			update();
		},
		"toggle-wan-address": function (e) {
			$("#wan-address a").toggleClass("hide");
		},
		"fetch-status": function (e) {
			fetchStatus();
		}
	});

	if (window.location.hash) {
		navigate(window.location.hash);
	}

	fetchStatus();
});
